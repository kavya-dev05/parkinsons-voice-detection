"""
Unit Tests - Parkinson's Disease Detection
Run: pytest tests/ -v
"""

import pytest
import numpy as np
import pandas as pd
import os
import sys
import pickle
import tempfile
import soundfile as sf

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.feature_extraction import (
    compute_jitter, compute_shimmer, compute_hnr,
    compute_dfa, compute_spectral_features
)


# ──────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────

@pytest.fixture
def sample_signal():
    """Generate a clean 440Hz sine wave at 22050 Hz."""
    sr = 22050
    duration = 2.0
    t = np.linspace(0, duration, int(sr * duration))
    y = 0.5 * np.sin(2 * np.pi * 440 * t).astype(np.float32)
    return y, sr


@pytest.fixture
def sample_wav_path(sample_signal):
    """Save the sine wave to a temp WAV file."""
    y, sr = sample_signal
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        sf.write(f.name, y, sr)
        yield f.name
    os.unlink(f.name)


# ──────────────────────────────────────────────
# Feature Extraction Tests
# ──────────────────────────────────────────────

class TestJitter:
    def test_zero_for_constant_pitch(self):
        pitch = [440.0] * 100
        assert compute_jitter(pitch) == pytest.approx(0.0, abs=1e-6)

    def test_positive_for_varying_pitch(self):
        pitch = [440.0, 442.0, 438.0, 441.0] * 25
        assert compute_jitter(pitch) > 0.0

    def test_short_series(self):
        """Should return 0 for series too short."""
        assert compute_jitter([440.0]) == 0.0

    def test_output_type(self):
        pitch = [440.0, 450.0, 430.0] * 10
        result = compute_jitter(pitch)
        assert isinstance(result, float)


class TestShimmer:
    def test_returns_float(self, sample_signal):
        y, sr = sample_signal
        result = compute_shimmer(y, sr)
        assert isinstance(result, float)

    def test_non_negative(self, sample_signal):
        y, sr = sample_signal
        assert compute_shimmer(y, sr) >= 0.0

    def test_noisy_signal_higher_shimmer(self, sample_signal):
        y, sr = sample_signal
        noisy = y + np.random.normal(0, 0.1, len(y)).astype(np.float32)
        assert compute_shimmer(noisy, sr) >= compute_shimmer(y, sr)


class TestHNR:
    def test_returns_float(self, sample_signal):
        y, sr = sample_signal
        result = compute_hnr(y, sr)
        assert isinstance(result, float)

    def test_clean_signal_positive_hnr(self, sample_signal):
        y, sr = sample_signal
        # A clean sine wave should have positive HNR
        assert compute_hnr(y, sr) > 0.0

    def test_pure_noise_lower_hnr(self, sample_signal):
        y, sr = sample_signal
        noise = np.random.normal(0, 1, len(y)).astype(np.float32)
        assert compute_hnr(y, sr) > compute_hnr(noise, sr)


class TestDFA:
    def test_returns_float(self, sample_signal):
        y, sr = sample_signal
        result = compute_dfa(y)
        assert isinstance(result, float)

    def test_range_reasonable(self, sample_signal):
        y, sr = sample_signal
        alpha = compute_dfa(y)
        # DFA alpha for typical signals should be between -1 and 3
        assert -1.0 <= alpha <= 3.0


class TestSpectralFeatures:
    def test_returns_four_values(self, sample_signal):
        y, sr = sample_signal
        result = compute_spectral_features(y, sr)
        assert len(result) == 4

    def test_all_non_negative(self, sample_signal):
        y, sr = sample_signal
        centroid, bandwidth, rolloff, zcr = compute_spectral_features(y, sr)
        assert centroid >= 0
        assert bandwidth >= 0
        assert rolloff >= 0
        assert zcr >= 0


# ──────────────────────────────────────────────
# Feature Extraction Integration Tests
# ──────────────────────────────────────────────

class TestExtractFeatures:
    def test_returns_dict(self, sample_wav_path):
        from src.feature_extraction import extract_features
        feats = extract_features(sample_wav_path)
        assert isinstance(feats, dict)

    def test_required_keys_present(self, sample_wav_path):
        from src.feature_extraction import extract_features
        feats = extract_features(sample_wav_path)
        required = ["MDVP:Fo(Hz)", "MDVP:Jitter(%)", "MDVP:Shimmer", "HNR", "NHR", "RPDE", "DFA"]
        for key in required:
            assert key in feats, f"Missing key: {key}"

    def test_all_values_finite(self, sample_wav_path):
        from src.feature_extraction import extract_features
        feats = extract_features(sample_wav_path)
        for k, v in feats.items():
            assert np.isfinite(v), f"Non-finite value for feature: {k}"

    def test_invalid_path_raises(self):
        from src.feature_extraction import extract_features
        with pytest.raises(Exception):
            extract_features("nonexistent_file.wav")


# ──────────────────────────────────────────────
# Prediction Tests (requires trained model)
# ──────────────────────────────────────────────

@pytest.mark.skipif(
    not os.path.exists("models/best_model.pkl"),
    reason="Model not trained yet. Run src/train_model.py first."
)
class TestPredict:
    def test_predict_from_audio(self, sample_wav_path):
        from src.predict import predict_from_audio
        result = predict_from_audio(sample_wav_path)
        assert "prediction" in result
        assert "label" in result
        assert result["prediction"] in [0, 1]
        assert 0 <= result["confidence_parkinsons"] <= 100
        assert 0 <= result["confidence_healthy"] <= 100

    def test_confidence_sums_to_100(self, sample_wav_path):
        from src.predict import predict_from_audio
        result = predict_from_audio(sample_wav_path)
        total = result["confidence_parkinsons"] + result["confidence_healthy"]
        assert abs(total - 100.0) < 0.1

    def test_risk_level_valid(self, sample_wav_path):
        from src.predict import predict_from_audio
        result = predict_from_audio(sample_wav_path)
        assert result["risk_level"] in ["MINIMAL", "LOW", "MODERATE", "HIGH"]


# ──────────────────────────────────────────────
# Data Loading Tests
# ──────────────────────────────────────────────

class TestDataLoader:
    @pytest.mark.skipif(
        not os.path.exists("data/parkinsons.data"),
        reason="Dataset not found. Download from UCI repository."
    )
    def test_load_data(self):
        from src.train_model import load_data, preprocess
        df = load_data()
        assert df is not None
        assert len(df) > 0

    @pytest.mark.skipif(
        not os.path.exists("data/parkinsons.data"),
        reason="Dataset not found."
    )
    def test_preprocess(self):
        from src.train_model import load_data, preprocess
        df = load_data()
        X, y = preprocess(df)
        assert X.shape[0] == y.shape[0]
        assert "status" not in X.columns
        assert "name" not in X.columns
        assert set(y.unique()).issubset({0, 1})


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
