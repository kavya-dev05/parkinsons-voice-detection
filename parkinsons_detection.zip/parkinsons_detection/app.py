"""
Flask Web Application - Parkinson's Disease Detection
Run: python app.py
"""

import os
import uuid
import json
import pickle
import numpy as np
import pandas as pd

from flask import Flask, request, jsonify, render_template, redirect, url_for
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "parkinsons_detection_secret_key"

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"wav", "mp3", "ogg", "flac"}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ─────────────────────────────────────────────
# Load model artifacts once at startup
# ─────────────────────────────────────────────

def load_model():
    try:
        model    = pickle.load(open("models/best_model.pkl", "rb"))
        scaler   = pickle.load(open("models/scaler.pkl", "rb"))
        selector = pickle.load(open("models/selector.pkl", "rb"))
        features = pickle.load(open("models/selected_features.pkl", "rb"))
        print("✅ Model loaded successfully.")
        return model, scaler, selector, features
    except FileNotFoundError:
        print("⚠️  Model not found. Run 'python src/train_model.py' first.")
        return None, None, None, None


MODEL, SCALER, SELECTOR, SELECTED_FEATURES = load_model()


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


# ─────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/predict/audio", methods=["POST"])
def predict_audio():
    """Endpoint: upload a voice file for prediction."""
    if MODEL is None:
        return jsonify({"error": "Model not loaded. Train the model first."}), 503

    if "file" not in request.files:
        return jsonify({"error": "No file uploaded."}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected."}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid file type. Use WAV, MP3, OGG, or FLAC."}), 400

    # Save uploaded file
    filename = f"{uuid.uuid4()}_{secure_filename(file.filename)}"
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    try:
        from src.feature_extraction import extract_features_for_model, extract_features

        raw_features = extract_features(filepath)
        X = extract_features_for_model(filepath, SELECTED_FEATURES, SCALER, SELECTOR)

        prediction  = MODEL.predict(X)[0]
        probability = MODEL.predict_proba(X)[0]

        result = {
            "prediction":    int(prediction),
            "label":         "Parkinson's Detected" if prediction == 1 else "Healthy",
            "confidence_parkinsons": round(float(probability[1]) * 100, 2),
            "confidence_healthy":    round(float(probability[0]) * 100, 2),
            "risk_level":    _risk_level(float(probability[1])),
            "key_features": {k: round(v, 5) for k, v in list(raw_features.items())[:10]},
        }

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    finally:
        # Clean up uploaded file
        if os.path.exists(filepath):
            os.remove(filepath)


@app.route("/predict/features", methods=["POST"])
def predict_features():
    """Endpoint: submit feature values manually (JSON body)."""
    if MODEL is None:
        return jsonify({"error": "Model not loaded."}), 503

    data = request.get_json()
    if not data:
        return jsonify({"error": "No JSON body provided."}), 400

    try:
        row = {f: data.get(f, 0.0) for f in SELECTED_FEATURES}
        df_row = pd.DataFrame([row])[SELECTED_FEATURES]

        scaled   = SCALER.transform(df_row)
        selected = SELECTOR.transform(scaled)

        prediction  = MODEL.predict(selected)[0]
        probability = MODEL.predict_proba(selected)[0]

        result = {
            "prediction":    int(prediction),
            "label":         "Parkinson's Detected" if prediction == 1 else "Healthy",
            "confidence_parkinsons": round(float(probability[1]) * 100, 2),
            "confidence_healthy":    round(float(probability[0]) * 100, 2),
            "risk_level":    _risk_level(float(probability[1])),
        }
        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/health")
def health():
    return jsonify({"status": "ok", "model_loaded": MODEL is not None})


def _risk_level(prob: float) -> str:
    if prob >= 0.80:   return "HIGH"
    elif prob >= 0.50: return "MODERATE"
    elif prob >= 0.30: return "LOW"
    else:              return "MINIMAL"


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
