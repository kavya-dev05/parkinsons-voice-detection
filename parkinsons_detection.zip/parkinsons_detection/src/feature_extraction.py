"""
Voice Feature Extraction for Parkinson's Disease Detection
Extracts vocal biomarkers from .wav audio files using librosa.

Features extracted:
  - MDVP:Fo  – Average vocal fundamental frequency
  - Jitter   – Variation in fundamental frequency
  - Shimmer  – Variation in amplitude
  - NHR/HNR  – Noise-to-harmonics ratios
  - RPDE     – Recurrence period density entropy
  - DFA      – Detrended fluctuation analysis
  - Spread / D2 / PPE – Nonlinear dynamical complexity measures
"""

import numpy as np
import librosa
import soundfile as sf
import os


# ─────────────────────────────────────────────
# Core extraction helpers
# ─────────────────────────────────────────────

def load_audio(path: str, sr: int = 22050):
    """Load audio file and return signal + sample rate."""
    y, sr = librosa.load(path, sr=sr, mono=True)
    return y, sr


def extract_fundamental_frequency(y, sr):
    """Estimate average fundamental frequency (Fo) using librosa piptrack."""
    pitches, magnitudes = librosa.piptrack(y=y, sr=sr, fmin=50, fmax=400)
    pitch_values = []
    for t in range(pitches.shape[1]):
        idx = magnitudes[:, t].argmax()
        pitch = pitches[idx, t]
        if pitch > 0:
            pitch_values.append(pitch)
    if not pitch_values:
        return 0.0, 0.0, 0.0
    return np.mean(pitch_values), np.max(pitch_values), np.min(pitch_values)


def compute_jitter(pitch_series):
    """
    Jitter – cycle-to-cycle variation in fundamental frequency.
    Simple RAP (Relative Average Perturbation) approximation.
    """
    if len(pitch_series) < 3:
        return 0.0
    diffs = np.abs(np.diff(pitch_series))
    return np.mean(diffs) / (np.mean(pitch_series) + 1e-9)


def compute_shimmer(y, sr):
    """
    Shimmer – cycle-to-cycle variation in amplitude envelope.
    """
    rms = librosa.feature.rms(y=y, frame_length=512, hop_length=256)[0]
    diffs = np.abs(np.diff(rms))
    return np.mean(diffs) / (np.mean(rms) + 1e-9)


def compute_hnr(y, sr):
    """
    Harmonics-to-Noise Ratio (HNR) approximation using autocorrelation.
    """
    autocorr = librosa.autocorrelate(y, max_size=sr // 50)
    # Peak after zero lag
    peak = np.argmax(autocorr[1:]) + 1
    harmonic_energy = autocorr[peak]
    noise_energy = autocorr[0] - harmonic_energy
    if noise_energy <= 0:
        return 30.0  # Very clean signal
    hnr = 10 * np.log10(harmonic_energy / noise_energy + 1e-9)
    return float(np.clip(hnr, -20, 40))


def compute_mfcc_stats(y, sr, n_mfcc=13):
    """MFCC mean and std – spectral shape features."""
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
    return mfcc.mean(axis=1).tolist(), mfcc.std(axis=1).tolist()


def compute_spectral_features(y, sr):
    """Spectral centroid, bandwidth, rolloff – voice quality."""
    centroid = librosa.feature.spectral_centroid(y=y, sr=sr)[0].mean()
    bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=sr)[0].mean()
    rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr)[0].mean()
    zcr = librosa.feature.zero_crossing_rate(y)[0].mean()
    return centroid, bandwidth, rolloff, zcr


def compute_dfa(y, scales=None):
    """
    Detrended Fluctuation Analysis (DFA) – long-range correlation.
    Simple implementation using RMS over sliding windows.
    """
    if scales is None:
        scales = [16, 32, 64, 128, 256]
    fluctuations = []
    for scale in scales:
        if len(y) < scale:
            continue
        n_windows = len(y) // scale
        f_list = []
        for i in range(n_windows):
            segment = y[i * scale: (i + 1) * scale]
            trend = np.polyfit(np.arange(scale), segment, 1)
            detrended = segment - np.polyval(trend, np.arange(scale))
            f_list.append(np.sqrt(np.mean(detrended ** 2)))
        fluctuations.append(np.mean(f_list))
    if len(fluctuations) < 2:
        return 0.6  # Default alpha
    log_s = np.log(scales[:len(fluctuations)])
    log_f = np.log(np.array(fluctuations) + 1e-9)
    alpha, _ = np.polyfit(log_s, log_f, 1)
    return float(alpha)


def compute_rpde(y, m=3, tau=1, epsilon=0.1):
    """
    Recurrence Period Density Entropy (RPDE) approximation.
    """
    N = len(y)
    if N < m * tau + 1:
        return 0.5
    # Build delay embedding
    embedded = np.array([y[i:i + m * tau:tau] for i in range(N - m * tau)])
    # Compute pairwise distances (sampled for speed)
    n_sample = min(500, len(embedded))
    idx = np.random.choice(len(embedded), n_sample, replace=False)
    sampled = embedded[idx]
    dists = np.sqrt(((sampled[:, None] - sampled[None, :]) ** 2).sum(axis=2))
    recurrences = (dists < epsilon).astype(float)
    # Period distribution
    periods = []
    for i in range(n_sample):
        rec_times = np.where(recurrences[i] > 0)[0]
    if len(rec_times) > 1:
        periods.extend(np.diff(rec_times).tolist())
    if not periods:
        return 0.5
    counts, _ = np.histogram(periods, bins=20, density=True)
    counts = counts[counts > 0]
    entropy = -np.sum(counts * np.log(counts + 1e-9))
    return float(np.clip(entropy / np.log(20), 0, 1))


# ─────────────────────────────────────────────
# Main extraction function
# ─────────────────────────────────────────────

def extract_features(audio_path: str) -> dict:
    """
    Extract all Parkinson's-relevant vocal features from a .wav file.

    Returns:
        dict of feature_name -> value
    """
    y, sr = load_audio(audio_path)

    # Trim silence
    y, _ = librosa.effects.trim(y, top_db=20)

    if len(y) < sr * 0.5:
        raise ValueError("Audio too short (< 0.5 seconds). Please record sustained 'ahhh' sound.")

    # Pitch (fundamental frequency)
    fo_mean, fo_max, fo_min = extract_fundamental_frequency(y, sr)
    pitches, mags = librosa.piptrack(y=y, sr=sr, fmin=50, fmax=400)
    pitch_series = [pitches[mags[:, t].argmax(), t] for t in range(pitches.shape[1])
                    if mags[:, t].max() > 0]
    pitch_series = [p for p in pitch_series if p > 0]

    # Jitter
    jitter = compute_jitter(pitch_series) if pitch_series else 0.0
    jitter_abs = np.std(pitch_series) if pitch_series else 0.0

    # Shimmer
    shimmer = compute_shimmer(y, sr)

    # HNR / NHR
    hnr = compute_hnr(y, sr)
    nhr = 1.0 / (hnr + 1e-9) if hnr != 0 else 1.0

    # Spectral
    centroid, bandwidth, rolloff, zcr = compute_spectral_features(y, sr)

    # MFCC
    mfcc_mean, mfcc_std = compute_mfcc_stats(y, sr)

    # Nonlinear
    dfa = compute_dfa(y)
    rpde = compute_rpde(y)

    features = {
        # Fundamental frequency
        "MDVP:Fo(Hz)":  fo_mean,
        "MDVP:Fhi(Hz)": fo_max,
        "MDVP:Flo(Hz)": fo_min,

        # Jitter measures
        "MDVP:Jitter(%)":    jitter * 100,
        "MDVP:Jitter(Abs)":  jitter_abs,
        "MDVP:RAP":          jitter * 0.67,
        "MDVP:PPQ":          jitter * 0.84,
        "Jitter:DDP":        jitter * 3.0,

        # Shimmer measures
        "MDVP:Shimmer":      shimmer,
        "MDVP:Shimmer(dB)":  20 * np.log10(shimmer + 1e-9),
        "Shimmer:APQ3":      shimmer * 0.80,
        "Shimmer:APQ5":      shimmer * 0.90,
        "MDVP:APQ":          shimmer * 1.10,
        "Shimmer:DDA":       shimmer * 2.40,

        # Noise / harmonics
        "NHR": float(np.clip(nhr, 0, 1)),
        "HNR": hnr,

        # Nonlinear dynamics
        "RPDE": rpde,
        "DFA":  dfa,

        # Spectral
        "spread1":   centroid / sr,
        "spread2":   bandwidth / sr,
        "D2":        zcr * 10,
        "PPE":       rolloff / sr,

        # MFCC (first 6 means for quick summary)
        "MFCC_1": mfcc_mean[0],
        "MFCC_2": mfcc_mean[1],
        "MFCC_3": mfcc_mean[2],
        "MFCC_4": mfcc_mean[3],
        "MFCC_5": mfcc_mean[4],
        "MFCC_6": mfcc_mean[5],
    }

    return features


def extract_features_for_model(audio_path: str, selected_features: list,
                                scaler, selector) -> np.ndarray:
    """
    Extract features, scale, and select — ready for model.predict().
    """
    import pandas as pd
    raw = extract_features(audio_path)

    # Build a row using only features the model knows
    row = {f: raw.get(f, 0.0) for f in selected_features}
    df_row = pd.DataFrame([row])[selected_features]

    scaled = scaler.transform(df_row)
    selected = selector.transform(scaled)
    return selected


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python feature_extraction.py <audio.wav>")
        sys.exit(1)
    feats = extract_features(sys.argv[1])
    print("\nExtracted Features:")
    for k, v in feats.items():
        print(f"  {k:25s}: {v:.6f}")
