"""
Parkinson's Disease Detection - Model Training
Uses vocal features extracted from voice recordings to classify Parkinson's disease.
Dataset: UCI Parkinson's Dataset (parkinsons.data)
"""

import numpy as np
import pandas as pd
import os
import pickle
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    roc_auc_score, roc_curve
)
from sklearn.feature_selection import SelectKBest, f_classif

import warnings
warnings.filterwarnings("ignore")


# ─────────────────────────────────────────────
# 1. Load & Explore Data
# ─────────────────────────────────────────────

def load_data(path="data/parkinsons.data"):
    df = pd.read_csv(path)
    print(f"Dataset shape: {df.shape}")
    print(f"\nClass distribution:\n{df['status'].value_counts()}")
    print(f"\nMissing values: {df.isnull().sum().sum()}")
    return df


def preprocess(df):
    # Drop name column (identifier, not a feature)
    df = df.drop(columns=["name"])

    X = df.drop(columns=["status"])
    y = df["status"]

    return X, y


# ─────────────────────────────────────────────
# 2. Feature Selection
# ─────────────────────────────────────────────

def select_features(X_train, y_train, X_test, k=15):
    selector = SelectKBest(score_func=f_classif, k=k)
    X_train_sel = selector.fit_transform(X_train, y_train)
    X_test_sel = selector.transform(X_test)

    selected_mask = selector.get_support()
    selected_features = X_train.columns[selected_mask].tolist()
    print(f"\nTop {k} selected features:\n{selected_features}")

    return X_train_sel, X_test_sel, selector, selected_features


# ─────────────────────────────────────────────
# 3. Train Models
# ─────────────────────────────────────────────

def train_svm(X_train, y_train):
    param_grid = {
        "C": [0.1, 1, 10, 100],
        "kernel": ["rbf", "linear"],
        "gamma": ["scale", "auto"]
    }
    grid = GridSearchCV(SVC(probability=True), param_grid, cv=5, scoring="accuracy", n_jobs=-1)
    grid.fit(X_train, y_train)
    print(f"\nSVM Best params: {grid.best_params_}")
    return grid.best_estimator_


def train_random_forest(X_train, y_train):
    param_grid = {
        "n_estimators": [100, 200],
        "max_depth": [None, 5, 10],
        "min_samples_split": [2, 5]
    }
    grid = GridSearchCV(RandomForestClassifier(random_state=42), param_grid, cv=5, scoring="accuracy", n_jobs=-1)
    grid.fit(X_train, y_train)
    print(f"\nRandom Forest Best params: {grid.best_params_}")
    return grid.best_estimator_


def train_gradient_boosting(X_train, y_train):
    clf = GradientBoostingClassifier(n_estimators=200, learning_rate=0.05, max_depth=3, random_state=42)
    clf.fit(X_train, y_train)
    return clf


# ─────────────────────────────────────────────
# 4. Evaluate
# ─────────────────────────────────────────────

def evaluate_model(model, X_test, y_test, model_name="Model"):
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)

    print(f"\n{'='*40}")
    print(f"  {model_name}")
    print(f"{'='*40}")
    print(f"  Accuracy : {acc:.4f}")
    print(f"  ROC AUC  : {auc:.4f}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['Healthy','Parkinson\'s'])}")

    return {"name": model_name, "model": model, "accuracy": acc, "auc": auc,
            "y_pred": y_pred, "y_prob": y_prob}


def plot_confusion_matrix(y_test, y_pred, model_name, save_dir="models"):
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Healthy", "Parkinson's"],
                yticklabels=["Healthy", "Parkinson's"])
    plt.title(f"Confusion Matrix - {model_name}")
    plt.ylabel("Actual")
    plt.xlabel("Predicted")
    plt.tight_layout()
    os.makedirs(save_dir, exist_ok=True)
    plt.savefig(f"{save_dir}/cm_{model_name.lower().replace(' ', '_')}.png", dpi=150)
    plt.close()


def plot_roc_curves(results, y_test, save_dir="models"):
    plt.figure(figsize=(7, 5))
    for r in results:
        fpr, tpr, _ = roc_curve(y_test, r["y_prob"])
        plt.plot(fpr, tpr, label=f"{r['name']} (AUC={r['auc']:.3f})")
    plt.plot([0, 1], [0, 1], "k--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curves - All Models")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"{save_dir}/roc_curves.png", dpi=150)
    plt.close()
    print("\nROC curve saved.")


# ─────────────────────────────────────────────
# 5. Save Best Model
# ─────────────────────────────────────────────

def save_artifacts(best_model, scaler, selector, selected_features, save_dir="models"):
    os.makedirs(save_dir, exist_ok=True)
    pickle.dump(best_model, open(f"{save_dir}/best_model.pkl", "wb"))
    pickle.dump(scaler, open(f"{save_dir}/scaler.pkl", "wb"))
    pickle.dump(selector, open(f"{save_dir}/selector.pkl", "wb"))
    pickle.dump(selected_features, open(f"{save_dir}/selected_features.pkl", "wb"))
    print(f"\nArtifacts saved to '{save_dir}/'")


# ─────────────────────────────────────────────
# 6. Main Pipeline
# ─────────────────────────────────────────────

def main():
    print("=" * 50)
    print("  Parkinson's Disease Detection - Training")
    print("=" * 50)

    # Load
    df = load_data()
    X, y = preprocess(df)

    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Scale
    scaler = StandardScaler()
    X_train_sc = pd.DataFrame(scaler.fit_transform(X_train), columns=X.columns)
    X_test_sc = pd.DataFrame(scaler.transform(X_test), columns=X.columns)

    # Feature selection
    X_train_sel, X_test_sel, selector, selected_features = select_features(X_train_sc, y_train, X_test_sc)

    # Train
    print("\n[1/3] Training SVM...")
    svm = train_svm(X_train_sel, y_train)

    print("\n[2/3] Training Random Forest...")
    rf = train_random_forest(X_train_sel, y_train)

    print("\n[3/3] Training Gradient Boosting...")
    gb = train_gradient_boosting(X_train_sel, y_train)

    # Evaluate
    results = []
    for model, name in [(svm, "SVM"), (rf, "Random Forest"), (gb, "Gradient Boosting")]:
        r = evaluate_model(model, X_test_sel, y_test, name)
        results.append(r)
        plot_confusion_matrix(y_test, r["y_pred"], name)

    plot_roc_curves(results, y_test)

    # Best model
    best = max(results, key=lambda x: x["accuracy"])
    print(f"\n✅ Best model: {best['name']} with accuracy {best['accuracy']:.4f}")

    save_artifacts(best["model"], scaler, selector, selected_features)
    print("\nTraining complete!")


if __name__ == "__main__":
    main()
