"""
Parkinson's Disease Detection - Prediction Module
Load trained model and run inference on a voice sample.
"""

import numpy as np
import pickle
import os
import sys

from src.feature_extraction import extract_features_for_model, extract_features


MODEL_DIR = "models"


def load_artifacts():
    """Load trained model, scaler, selector, and feature list."""
    try:
        model    = pickle.load(open(f"{MODEL_DIR}/best_model.pkl", "rb"))
        scaler   = pickle.load(open(f"{MODEL_DIR}/scaler.pkl", "rb"))
        selector = pickle.load(open(f"{MODEL_DIR}/selector.pkl", "rb"))
        features = pickle.load(open(f"{MODEL_DIR}/selected_features.pkl", "rb"))
        return model, scaler, selector, features
    except FileNotFoundError:
        print("❌ Model not found. Run 'python src/train_model.py' first.")
        sys.exit(1)


def predict_from_audio(audio_path: str) -> dict:
    """
    Run full inference pipeline on a .wav file.

    Returns:
        dict with keys: prediction, confidence, risk_level, features
    """
    if not os.path.exists(audio_path):
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    model, scaler, selector, selected_features = load_artifacts()

    # Extract raw features (for display)
    raw_features = extract_features(audio_path)

    # Prepare for model
    X = extract_features_for_model(audio_path, selected_features, scaler, selector)

    # Predict
    prediction = model.predict(X)[0]
    probability = model.predict_proba(X)[0]

    conf_healthy    = float(probability[0])
    conf_parkinsons = float(probability[1])

    risk_level = _get_risk_level(conf_parkinsons)

    result = {
        "prediction":    int(prediction),
        "label":         "Parkinson's Detected" if prediction == 1 else "Healthy",
        "confidence_parkinsons": round(conf_parkinsons * 100, 2),
        "confidence_healthy":    round(conf_healthy * 100, 2),
        "risk_level":    risk_level,
        "features":      raw_features,
    }

    return result


def _get_risk_level(prob: float) -> str:
    if prob >= 0.80:
        return "HIGH"
    elif prob >= 0.50:
        return "MODERATE"
    elif prob >= 0.30:
        return "LOW"
    else:
        return "MINIMAL"


def predict_from_features(feature_dict: dict) -> dict:
    """
    Run inference from a pre-computed feature dictionary
    (e.g., from the web form / manual input).
    """
    import pandas as pd

    model, scaler, selector, selected_features = load_artifacts()

    row = {f: feature_dict.get(f, 0.0) for f in selected_features}
    df_row = pd.DataFrame([row])[selected_features]

    scaled   = scaler.transform(df_row)
    selected = selector.transform(scaled)

    prediction  = model.predict(selected)[0]
    probability = model.predict_proba(selected)[0]

    conf_parkinsons = float(probability[1])
    conf_healthy    = float(probability[0])

    return {
        "prediction":    int(prediction),
        "label":         "Parkinson's Detected" if prediction == 1 else "Healthy",
        "confidence_parkinsons": round(conf_parkinsons * 100, 2),
        "confidence_healthy":    round(conf_healthy * 100, 2),
        "risk_level":    _get_risk_level(conf_parkinsons),
    }


def print_result(result: dict):
    print("\n" + "=" * 50)
    print("  PARKINSON'S DISEASE DETECTION RESULT")
    print("=" * 50)
    print(f"  Prediction   : {result['label']}")
    print(f"  Risk Level   : {result['risk_level']}")
    print(f"  Confidence   :")
    print(f"    Parkinson's : {result['confidence_parkinsons']}%")
    print(f"    Healthy     : {result['confidence_healthy']}%")
    print("=" * 50)
    print("\n⚠️  Disclaimer: This is a research tool only.")
    print("    Please consult a medical professional for diagnosis.\n")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python predict.py <audio.wav>")
        sys.exit(1)

    audio_file = sys.argv[1]
    print(f"\nAnalysing: {audio_file}")

    try:
        result = predict_from_audio(audio_file)
        print_result(result)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
