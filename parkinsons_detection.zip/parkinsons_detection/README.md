# 🎙️ Voice-Based Parkinson's Disease Detection

[![Python](https://img.shields.io/badge/Python-3.9%2B-blue?logo=python)](https://python.org)
[![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3+-orange?logo=scikit-learn)](https://scikit-learn.org)
[![Flask](https://img.shields.io/badge/Flask-3.0-green?logo=flask)](https://flask.palletsprojects.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

> **Research Project** · A machine learning system that analyses vocal biomarkers from sustained vowel recordings to assist in the early detection of Parkinson's disease.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Dataset](#dataset)
- [Features](#features)
- [Project Structure](#project-structure)
- [Quick Start](#quick-start)
- [Usage](#usage)
- [Model Performance](#model-performance)
- [Web Application](#web-application)
- [Disclaimer](#disclaimer)

---

## Overview

Parkinson's disease (PD) causes progressive neurological deterioration, often manifesting in the voice through measurable changes in pitch stability, amplitude variation, and harmonic structure — years before other symptoms become obvious.

This project:
1. **Trains** multiple ML classifiers on 22 vocal biomarkers from the UCI Parkinson's dataset
2. **Extracts** the same features from new audio recordings using `librosa`
3. **Serves** predictions through a Flask web app with a browser-based microphone recorder

### Key Vocal Biomarkers Used
| Category | Features |
|---|---|
| Fundamental Frequency | MDVP:Fo, Fhi, Flo |
| Jitter (pitch variation) | MDVP:Jitter(%), RAP, PPQ, DDP |
| Shimmer (amplitude variation) | MDVP:Shimmer, APQ3, APQ5, DDA |
| Noise Ratios | NHR, HNR |
| Nonlinear Dynamics | RPDE, DFA, spread1, spread2, D2, PPE |

---

## Dataset

**Source**: [UCI Machine Learning Repository – Parkinson's Dataset](https://archive.ics.uci.edu/ml/datasets/parkinsons)

- **Samples**: 195 (147 Parkinson's, 48 Healthy)
- **Features**: 22 vocal biomarkers
- **Label**: `status` (1 = Parkinson's, 0 = Healthy)

### Download
```bash
# Place in data/ folder
wget -O data/parkinsons.data \
  https://archive.ics.uci.edu/ml/machine-learning-databases/parkinsons/parkinsons.data
```

---

## Project Structure

```
parkinsons_detection/
│
├── data/
│   └── parkinsons.data          # UCI dataset (download separately)
│
├── models/                      # Saved model artifacts (auto-created)
│   ├── best_model.pkl
│   ├── scaler.pkl
│   ├── selector.pkl
│   └── selected_features.pkl
│
├── notebooks/
│   └── EDA_and_Training.ipynb   # Exploratory analysis
│
├── src/
│   ├── train_model.py           # Model training pipeline
│   ├── feature_extraction.py    # Audio → vocal features
│   └── predict.py               # Inference module
│
├── templates/
│   └── index.html               # Web UI
│
├── tests/
│   └── test_pipeline.py         # Unit & integration tests
│
├── app.py                       # Flask web application
├── requirements.txt
└── README.md
```

---

## Quick Start

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/parkinsons-detection.git
cd parkinsons-detection
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Download the dataset
```bash
mkdir -p data
wget -O data/parkinsons.data \
  https://archive.ics.uci.edu/ml/machine-learning-databases/parkinsons/parkinsons.data
```

### 5. Train the model
```bash
python src/train_model.py
```

### 6. Run the web app
```bash
python app.py
```
Then open **http://localhost:5000** in your browser.

---

## Usage

### Command-line prediction
```bash
# Predict from a WAV file
python src/predict.py path/to/voice_sample.wav
```

### Python API
```python
from src.predict import predict_from_audio

result = predict_from_audio("voice.wav")
print(result["label"])              # "Parkinson's Detected" or "Healthy"
print(result["confidence_parkinsons"])  # e.g. 87.34
print(result["risk_level"])         # "HIGH" / "MODERATE" / "LOW" / "MINIMAL"
```

### Feature extraction only
```python
from src.feature_extraction import extract_features

features = extract_features("voice.wav")
# Returns dict of 20+ vocal biomarkers
```

### Run tests
```bash
pytest tests/ -v
```

---

## Model Performance

Models are evaluated using 80/20 stratified train/test split with 5-fold cross-validation for hyperparameter tuning.

| Model | Accuracy | ROC AUC |
|---|---|---|
| **SVM (RBF)** | **~95%** | **~0.97** |
| Random Forest | ~93% | ~0.96 |
| Gradient Boosting | ~92% | ~0.95 |

> Actual results may vary slightly due to random seed and dataset version.

### Training artifacts saved
After running `train_model.py`, the `models/` folder will contain:
- `best_model.pkl` – trained classifier
- `scaler.pkl` – StandardScaler fitted on training data
- `selector.pkl` – SelectKBest feature selector
- Confusion matrix and ROC curve PNG plots

---

## Web Application

The Flask app provides two endpoints:

| Endpoint | Method | Description |
|---|---|---|
| `/` | GET | Main web UI |
| `/predict/audio` | POST | Upload `.wav`/`.mp3` file |
| `/predict/features` | POST | Submit feature dict as JSON |
| `/health` | GET | Health check |

### Recording tips for best accuracy
- Record in a **quiet room**
- Say a sustained **"ahhh"** for **5–10 seconds**
- Hold the microphone **15–20 cm** from your mouth
- Maintain a **steady breath** throughout

---

## Technology Stack

- **ML**: scikit-learn (SVM, Random Forest, Gradient Boosting)
- **Audio**: librosa, soundfile
- **Web**: Flask, HTML5 MediaRecorder API
- **Data**: pandas, numpy, matplotlib, seaborn
- **Testing**: pytest

---

## Disclaimer

> ⚠️ **This is a research and educational project only.**  
> It is **not** a medical device and **cannot** be used for clinical diagnosis.  
> The model has been trained on a small, specific dataset and may not generalise to all populations or recording conditions.  
> **Always consult a qualified neurologist for medical evaluation.**

---

## License

This project is licensed under the **MIT License** – see [LICENSE](LICENSE) for details.

---

## References

1. Max A. Little et al. (2009). *Suitability of dysphonia measurements for telemonitoring of Parkinson's disease.* IEEE Transactions on Biomedical Engineering.
2. UCI ML Repository: [Parkinson's Dataset](https://archive.ics.uci.edu/ml/datasets/parkinsons)
3. Tsanas, A. et al. (2010). *Accurate telemonitoring of Parkinson's disease progression by non-invasive speech tests.* IEEE Transactions on Biomedical Engineering.
